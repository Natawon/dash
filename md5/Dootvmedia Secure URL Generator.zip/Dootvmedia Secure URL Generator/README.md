# ByteArk SDK PHP Example

This project is an example usage for [ByteArk SDK PHP](https://github.com/byteark/byteark-sdk-php) to generate secure URLs via web form.

You may try the [live demo](https://docs.byteark.com/examples/byteark-sdk-php-example).

## Installation

1. Clone this project.
2. Run `composer install`.
3. Point your web server to `public` directory.
